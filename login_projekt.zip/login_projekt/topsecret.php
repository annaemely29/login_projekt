<?php
include 'header.php';
?>

<br><br><br>

<h1>This site is top secret! Shhhhhh...</h1>

<br><br>

<img src="DSC08064.jpg" alt="pomeranian">

</body>
</html>