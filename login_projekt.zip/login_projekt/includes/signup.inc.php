<?php session_start();?>
<?php 
include '../dbh.php';


//oprettelse af variabler

$first = $_POST['first'];
$last = $_POST['last'];
$uid = $_POST['uid'];
$pwd = $_POST['pwd'];

/*for at teste variablerne bliver de echoet ud 

echo $first."<br>";
echo $last."<br>";
echo $uid."<br>";
echo $pwd."<br>";

*/

//Dette script tjekker om der er tomme felter. Dette gøres igennem en if statement. ?error=empty er ligesom en GET som vises i URL. der laves en if statement til hvert felt

if (empty($first)){
	header("Location: ../signup.php?error=empty");
	exit();
	} 

if (empty($last)){
	header("Location: ../signup.php?error=empty");
	exit();
	} 

if (empty($uid)){
	header("Location: ../signup.php?error=empty");
	exit();
	} 

if (empty($pwd)){
	header("Location: ../signup.php?error=empty");
	exit();
	} 	else {
	
		$sql = "SELECT uid FROM user WHERE uid='$uid'";
		$result = $conn->query($sql);
		$uidcheck = mysqli_num_rows($result);
			if ($uidcheck > 0){
				header("Location: ../signup.php?error=username");
				exit();
		}	else {
		//for at sikre password anvendes hashing. Således kan password ikke ses i database
		$enc_password = password_hash($pwd, PASSWORD_DEFAULT);
		$sql = "INSERT INTO user (first, last, uid, pwd) 
		VALUES ('$first', '$last', '$uid','$enc_password')";
		
				$result = $conn->query($sql);
				header("Location: ../index.php");
				}}?>
<!--for at blive sendt tilbage til forsiden når man trykker sign up-->