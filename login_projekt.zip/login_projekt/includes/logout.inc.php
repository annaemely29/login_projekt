<?php 
	session_start();
	session_destroy();
	header ("Location: ../index.php");
	
	//for at stoppe sessionen skrives destroy. header sender en tilbage på forsiden