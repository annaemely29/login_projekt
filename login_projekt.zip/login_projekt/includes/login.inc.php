<?php session_start();

include '../dbh.php';


//oprettelse af variabler

$uid = $_POST['uid'];
$pwd = $_POST['pwd'];

/*for at teste variablerne bliver de echoet ud 

echo $first."<br>";
echo $last."<br>";
echo $uid."<br>";
echo $pwd."<br>";

*/

//for at sikre bruger id og password og sørge for de hænger sammen. På denne måde dekrypterer siden passwordet således det kan læses 
$sql = "SELECT * FROM user WHERE uid='$uid'";	
$result = $conn->query($sql);
$row = mysqli_fetch_assoc($result);
$hash_pwd = $row['pwd'];
$hash = password_verify($pwd, $hash_pwd);

//tjekker om ovenstående funktion er falsk. 
if ($hash == 0){
		header("Location: ../index.php?error=empty");
		exit();
		} else {


//hvis et password og et username matcher nu kan der logges ind. hash_pwd skal skrives her idet det er denne der skal findes

$sql = "SELECT * FROM user WHERE uid='$uid' AND pwd='$hash_pwd'";
$result = $conn->query($sql);


//for at finde ud af om man er logget ind laves en if statement. Her bliver en session også indsat

if (!$row = mysqli_fetch_assoc($result)) {
		echo "Your username or password is incorrect!";
	} else {
		$_SESSION['id'] = $row['id'];
		}



//for at blive sendt til topsecret site når man trykker log in

header("Location: ../topsecret.php"); } 