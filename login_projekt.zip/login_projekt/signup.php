<?php include 'header.php';?>
<!--inkluderer alt som er i headeren-->
<br><br><br>

<?php


	//variable laves ud fra URL. Superglobal der henter data fra serveren. strpos ser på strings og skal se på string error=empty
	$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		if (strpos($url, 'error=empty') !== false){
			echo "<p>Fill out all fields!</p>";
			}
		
		else if (strpos($url, 'error=username') !== false){
			echo "<p>Username already exists</p>";
			}


	if (isset($_SESSION['id'])) {
			echo $_SESSION['id'];
		} else {
			echo "<p>You are not logged in! Sign up below!</p>";
			}
?>

<br><br><br>

<!--hvis denne session er der, skal følgende echos ud, og hvis ikke man logges ind kommer følgende besked-->
<?php
	if (isset($_SESSION['id'])) {
			echo "<p>You are already logged in!</p>";
		} else {
			echo //sign up form
			"<form class='forms' action='includes/signup.inc.php' method='POST'>
				<input class='box' type='text' name='first' placeholder='Firstname'><br>
				<input class='box' type='text' name='last' placeholder='Lastname'><br>
				<input class='box' type='text' name='uid' placeholder='Username'><br>
				<input class='box' type='password' name='pwd' placeholder='Password'><br>
    
    		<button class='knap' type='submit'>SIGN UP</button>

			</form>";
			}
?>





</body>
</html>