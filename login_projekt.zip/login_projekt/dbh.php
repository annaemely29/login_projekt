<?php
//Denne sidde skaber forbindelse til databasen. If statement fortæller om forbindelsen er igennem

$conn = mysqli_connect("annaemely.dk.mysql", "annaemely_dk", "ntDgZikb", "annaemely_dk");


if (!$conn){
		die("Ingen forbindelse " .mysqli_connect_error());
	}