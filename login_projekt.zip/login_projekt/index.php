<?php include 'header.php';?>
<!--inkluderer alt som er i headeren-->
<br><br><br>

<h1>Welcome!</h1>
<h2>Login or sign up!</h2>


<!--hvis denne session er der, skal følgende echos ud, og hvis ikke man logges ind kommer følgende besked-->
<?php
	if (isset($_SESSION['id'])) {
			echo "<p>You are logged in!</p>";
		} else {
			echo "<p>You are not logged in!</p>";
			}
?>



</body>
</html>