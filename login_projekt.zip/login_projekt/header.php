<?php session_start();?>
<!--For at starte en session-->

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Login projekt</title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">

</head>

<body>

	<header>
    	<nav>
        	<ul>
            	<li><a href="index.php">Home</a></li>
                <?php
				//log in form
					if (isset($_SESSION['id'])) {
						//log ud knap - topsecret vises kun ved login
						echo "<form action='includes/logout.inc.php'>
							<button>LOG OUT</button>
						</form> 
						<li><a href='topsecret.php'>Secret page</a></li>";

					} else {
						echo "<form action='includes/login.inc.php' method='POST'>
    					<input type='text' name='uid' placeholder='Username'>
    					<input type='password' name='pwd' placeholder='Password'>
    
   						<button type='submit'>LOGIN</button>
						</form>";
						}
				?>
               
                <li><a href="signup.php">Sign up</a></li>
            </ul>
        </nav>
    </header>